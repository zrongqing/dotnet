﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotnetTool.RegularTool
{
    /// <summary>
    /// 正则表达式的常用
    /// </summary>
    public class RegularTool
    {
    }
}
