# WindowsToast

## 序

+ 淡入淡出弹出Toast提示框
+ 显示固定时长后自动消失
+ 友好性图标
+ 可根据父容器定位
————————————————
TopLeft-------TopCenter------TopRight
|                 |                 |
CenterLeft-----Center-----CenterRight
|                 |                 |
BottomLeft--BottomCenter--BottomRight
————————————————
+ 可根据显示器定位，并去除任务栏高度和宽度
TopLeft-------TopCenter------TopRight
|                 |                 |
CenterLeft-----Center-----CenterRight
|                 |                 |
BottomLeft--BottomCenter--BottomRight
================任务栏================
+ 可跟随父容器一起移动
+ 可根据父容器大小改变自动计算新位置
+ 可添加提示框关闭事件和单击事件
