﻿#region << 版 本 注 释 >>
/*----------------------------------------------------------------
* 项目名称 ：HWCommonUI.RegularExpression
* 项目描述 ：
* 类 名 称 ：RegularTool
* 类 描 述 ：
* 命名空间 ：HWCommonUI.RegularExpression
* 作    者 ：zrq 
* 创建时间 ：2020/11/23 17:49:12
* 更新时间 ：2020/11/23 17:49:12
*******************************************************************
* Copyright @ 58317 2020. All rights reserved.
*******************************************************************
//----------------------------------------------------------------*/
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWCommonUI.RegularExpression
{
    /// <summary>
    /// 正则表达式工具
    /// </summary>
    /// <remarks>
    /// 2021年10月13日 zrq 汇总一些正则表达式的写法
    /// </remarks>
    public class RegularTool
    {
    }
}
